# 面经项目配置

## 参考文件
- 面经格式参考本仓库中的 `快手一面面经.md`
- 简历参考本仓库中的 `简历_谭演锋_四月初可到岗.pdf`

## Skills（技能参考）
创建或编辑 Obsidian 笔记前，先阅读对应的 skill 文件：
- Obsidian Markdown 语法：`.claude/skills/obsidian-markdown/SKILL.md`
- Obsidian CLI 操作：`.claude/skills/obsidian-cli/SKILL.md`
- Obsidian Bases：`.claude/skills/obsidian-bases/SKILL.md`
- JSON Canvas：`.claude/skills/json-canvas/SKILL.md`

## 工作规则
1. 生成面经时，模仿 `快手一面面经.md` 的格式（按题目分区，包含"当时的回答"和"改进后的回答"）
2. 讨论实习内容时，参考简历
3. 面经文件直接写入本仓库对应分区
4. 把相关问题通过 `[[双链]]` 连接到 Agent技术专栏 和 Java后端技术专栏
5. 查看已有面经，把常问的、已回答过的问题通过双链互相连接
6. 发现冗余废话或不同文档描述同一件事时，删除或用双链连接
7. 约 10 轮对话 commit 一次，自行决定频率
8. 八股问题更新到对应专栏的 markdown 文档里，或新建文档存储

## Obsidian 笔记规范
- 所有笔记使用 YAML frontmatter（title, tags, date）
- 内部链接使用 `[[wikilink]]` 格式
- 外部链接使用标准 markdown `[text](url)` 格式
- 标签使用 `tags` 属性在 frontmatter 中定义

## 代码风格
简单、最小化、直接、避免过度工程化
